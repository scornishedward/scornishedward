
# Get the directory name for data files
import os.path
directory = os.path.dirname(os.path.abspath(__file__))  

#initialize the aggregators
num_likes=[]
num_wins=[]


# Scan one file at a time
for wins in range(0,60):
    # Open the file
    filename = os.path.join(directory, 'Data Project NBA' + '.txt')
    datafile = open(filename,'r')
    # Go through all the scores and likes
    for line in datafile:
        #separates the likes from wins
        wins, likes = line.split(',')
        #adds number of wins to a list
        num_wins += [wins]
        #adds number of likes to a list
        num_likes += [likes]
      
    #Close the file
    datafile.close()

# Plot on one set of axes.
import matplotlib.pyplot as plt
fig, ax = plt.subplots(1,1)
ax.plot(num_wins, num_likes, 'ro')
#label the y axis
plt.ylabel('Likes on Facebook')
#label the x axis
plt.xlabel('Wins in 2015-2016 Season')
#title the graph
ax.set_title('NBA Teams Likes on Facebook v. Wins in 2015-2016 Season')
#show the original graph as a scatter plot
fig.show()
#save the graph as a scatterplot
fig.savefig('NBA Scatter.png')
#data points for the line of best fit
best_fit_y = [854452, 9931045]
best_fit_x = [10,80]
#plots line of best fit across scatter plot
ax.plot(best_fit_x, best_fit_y)
#shows the scatter plot with a line of best fit
fig.show()
#saves the scatterplot with a line of best fit
fig.savefig('NBA Scatter Best Fit.png')